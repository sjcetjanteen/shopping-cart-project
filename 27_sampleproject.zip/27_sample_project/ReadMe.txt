cart
Basic project structure
========================
    bin (codes to run project)
        www (start up file)
    config (configurations, like database connection)
        config (configuration file)
    controller (CRUD operations)

    models (Collection Schemas)
        models.js
    public (static files, like css, js, images etc.)
        css
        js
        lib
            bootstrap
            jquery
    routes (url paths)

    views (front end design)
        layouts


    app.js (connecting all codes, and middleware)



users:-
    guest
    customer
    admin
    stock
    sales


To generate basic package.json file
====================================

//will ask basic details
z:/> npm init

//without asking details
z:/> npm init -y

//install packages

z:/> npm i express
//view engine
z:/> npm i ejs
//post method
z:/> npm i body-parser

//automatically load modifications without restarting the project
z:/> npm i nodemon
z:/> npm i body-parser

NB:- while sharing project delete folder "node_modules",
after receiving the shared project give the following command. 

z:/> npm install