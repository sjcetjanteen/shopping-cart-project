const express = require('express')
// File upload
const multer = require('multer')
const { connectDB } = require('./config/config')
const { UserType } = require('./models/models')
const app = express()

// setting ejs as view engine
app.set('view engine', 'ejs')
// giving permission to access static files from public folder
app.use(express.static("public"))
// for Post method
app.use(express.urlencoded({ extended: true }))
// Using Session
app.use(require('express-session')({
    secret: "12345@ABC",
    resave: true,
    saveUninitialized: false
}))

// file upload
app.use(multer({ dest: '/public/uploads/' }).any())
// middleware
app.use((req, res, next) => {
    res.locals.title = ""
    let user = { id: "", name: "", utype: "" }
    if (req.session.user !== undefined) {
        user = req.session.user
    }
    res.locals.user = user
    res.locals.msg = ''

    next()
})
// Load Database
connectDB().then(() => {
    console.log('database connected...')
    const usertypes = [
        { _id: 1, type: 'admin' },
        { _id: 2, type: 'stock' },
        { _id: 3, type: 'sales' },
        { _id: 4, type: 'customer' },
    ]
    UserType.find().then((data) => {
        if (!data.length) {
            UserType.insertMany(usertypes).then((data) => {
                console.log(data)
            })
        }
    })
})

app.use('/', require('./routes/guest'))
app.use('/admin', require('./routes/admin'))
app.use('/customer', require('./routes/customer'))

module.exports = app