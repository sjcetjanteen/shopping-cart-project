const express = require('express')
const { Category, nextId } = require('../models/models')
const router = express()

router.get('/', async (req, res) => {
    let data = await Category.find()
    res.render('admin/category/read', { title: "Categories", datas: data })
})

router.get('/create', (req, res) => {
    res.render('admin/category/create', { title: "Add Category" })
})

router.post('/create', async (req, res) => {
    Category.create({
        _id: await nextId("category"),
        name: req.body.name
    }).then((data) => {
        res.render('admin/category/create', {
            title: "Add Category",
            msg: `${data.name} Saved !!!`
        })
    }).catch((error) => {
        res.render('admin/category/create', {
            title: "Add Category",
            msg: error.toString()
        })
    })

})

router.get('/update/:id', async (req, res) => {
    let d = await Category.findById(req.params.id)
    res.render('admin/category/update', { title: "Modify Category", data: d })
})

router.post('/update/:id', async (req, res) => {
    let d = await Category.findByIdAndUpdate(req.params.id, {
        name: req.body.name
    })
    res.redirect('/admin/category')
})

router.get('/delete/:id', async (req, res) => {
    let d = await Category.findById(req.params.id)
    res.render('admin/category/delete', { title: "Delete Category", data: d })
})
router.post('/delete/:id', async (req, res) => {
    let d = await Category.findByIdAndDelete(req.params.id)
    res.redirect('/admin/category')
})

module.exports = router