const express = require('express')
const router = express()

router.get('/', (req, res) => {
    res.render('admin/home', { title: "Admin Home" })
})

router.use('/category', require('./category'))
router.use('/product', require('./product'))
module.exports = router