const express = require('express')
const { Product } = require('../models/models')
const router = express()

router.get('/', async (req, res) => {
    // replace with stock after stock CRUD compleated
    let datas = await Product.find()
    res.render('customer/home', { title: "Customer Home", datas: datas })
})

module.exports = router