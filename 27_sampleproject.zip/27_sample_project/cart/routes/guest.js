const express = require('express')
const { User, nextId } = require('../models/models')
const router = express()

router.get('/', (req, res) => {
    res.render('guest/home', { title: "Public Home" })
})

router.get('/register', (req, res) => {
    res.render('guest/register', { title: "Register", status: "", msg: "" })
})

router.post('/register', async (req, res) => {
    let usr = User.create({
        _id: await nextId("user"),
        name: req.body.name,
        address: req.body.address,
        contact: req.body.contact,
        email: req.body.email,
        password: req.body.password,
        usertype: 4
    })
    usr.then(
        (data) => {
            res.render('guest/register', {
                title: "Register"
                , status: "OK",
                msg: `${data.name} Registered Successfully !!!`
            })
        },
        (error) => {
            res.render('guest/register', {
                title: "Register",
                status: "Error",
                msg: error.toString()
            })
        }
    )

})

router.get('/login', (req, res) => {
    res.render('guest/login', { title: "Sign In", msg: '' })
})
router.post('/login', (req, res) => {
    let data = User.find({
        email: req.body.email,
        password: req.body.password
    }).populate('usertype')
    data.then((datas) => {
        if (datas.length) {
            let d = datas[0]
            req.session.user = {
                id: d._id,
                name: d.name,
                utype: d.usertype.type
            }
            res.redirect("/" + d.usertype.type)
        } else {
            res.render('guest/login', {
                title: "Sign In",
                msg: 'Invalid User Name/Password ?'
            })
        }
    })
})

router.get('/signout', (req, res) => {
    req.session.destroy()
    res.redirect('login')
})

module.exports = router