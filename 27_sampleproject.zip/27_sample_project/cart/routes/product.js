const express = require('express')
const fs = require('fs')
const { Product, nextId, Category } = require('../models/models')
const router = express()

router.get('/', async (req, res) => {
    let data = await Product.find().populate('category')
    res.render('admin/product/read', { title: "Products", datas: data })
})

router.get('/create', async (req, res) => {
    let data = await Category.find()
    res.render('admin/product/create', { title: "Add Product", cats: data })
})

router.post('/create', async (req, res) => {
    let categories = await Category.find()
    let id = await nextId("product")
    // if file name is "apple.png" then "png" is saving
    let extension = req.files[0].originalname.split('.')[1]
    let filename = `${id}.${extension}`
    fs.readFile(req.files[0].path, (error, data) => {
        if (error) {
            res.render('admin/product/create', {
                title: "Add Product",
                msg: error.toString(), cats: categories
            })
        } else {//start read file else
            // removing folder name routes from real path
            let file_path = __dirname.replace("routes", "")
            fs.writeFile(`${file_path}/public/uploads/${filename}`
                , data, (error, data) => {
                    if (error) {
                        res.render('admin/product/create', {
                            title: "Add Product",
                            msg: error.toString(), cats: categories
                        })
                    } else {//start write file else
                        Product.create({
                            _id: id,
                            name: req.body.name,
                            category: req.body.category,
                            image: filename
                        }).then((data) => {
                            res.render('admin/product/create', {
                                title: "Add Product",
                                msg: `${data.name} Saved !!!`, cats: categories
                            })
                        }).catch((error) => {
                            res.render('admin/product/create', {
                                title: "Add Product",
                                msg: error.toString(), cats: categories
                            })
                        })
                    }//end write file else
                })// end write file
        }//end read file else
    })//end read file
})

router.get('/update/:id', async (req, res) => {
    let categories = await Category.find()
    let d = await Product.findById(req.params.id)
    res.render('admin/product/update', { title: "Modify Product", data: d, cats: categories })
})

router.post('/update/:id', async (req, res) => {
    let categories = await Category.find()
    let id = req.params.id
    // if file name is "apple.png" then "png" is saving
    let extension = req.files[0].originalname.split('.')[1]
    let filename = `${id}.${extension}`
    fs.readFile(req.files[0].path, (error, data) => {
        if (error) {
            res.render('admin/product/update/' + id, {
                title: "Add Product",
                msg: error.toString(), cats: categories
            })
        } else {//start read file else
            // removing folder name routes from real path
            let file_path = __dirname.replace("routes", "")
            fs.writeFile(`${file_path}/public/uploads/${filename}`
                , data, async (error, data) => {
                    if (error) {
                        res.render('admin/product/update/' + id, {
                            title: "Modify Product",
                            msg: error.toString(), cats: categories
                        })
                    } else {//start write file else
                        await Product.findByIdAndUpdate(id, {
                            _id: id,
                            name: req.body.name,
                            category: req.body.category,
                            image: filename
                        })
                        res.redirect('/admin/product')
                    }//end write file else
                })// end write file
        }//end read file else
    })//end read file
})

router.get('/delete/:id', async (req, res) => {
    let categories = await Category.find()
    let d = await Product.findById(req.params.id)
    res.render('admin/product/delete', { title: "Delete Product", data: d, cats: categories })
})
router.post('/delete/:id', async (req, res) => {
    let d = await Product.findByIdAndDelete(req.params.id)
    res.redirect('/admin/product')
})

module.exports = router