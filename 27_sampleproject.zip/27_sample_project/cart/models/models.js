const mongoose = require('mongoose')
const Schema = mongoose.Schema
const model = mongoose.model

// usertype:- _id#, type
const UsertTypeSchema = new Schema({
    _id: Number,
    type: { type: String, unique: true, lowercase: true, trim: true }
})
const UserTypeModel = model("usertype", UsertTypeSchema)

// user:- _id#,name,address,contact,username(email),password,usertype(fk ManyToOne)

const UserSchema = new Schema({
    _id: Number,
    name: String,
    address: String,
    contact: String,
    email: { type: String, unique: true, lowercase: true, trim: true },
    password: { type: String, select: false },
    usertype: { type: Number, ref: "usertype" }
})
const UserModel = model("user", UserSchema)
// category:- _id#, name
const CategorySchema = new Schema({
    _id: Number,
    name: { type: String, unique: true, lowercase: true, trim: true }
})
const CategoryModel = model("category", CategorySchema, "categories")
// product:- _id#, name, category(fk ManyToOne), image
const ProductSchema = new Schema({
    _id: Number,
    name: { type: String, unique: true, lowercase: true, trim: true },
    category: { type: Number, ref: "category" },
    image: String
})
const ProductModel = model("product", ProductSchema)
// stock:- _id#,product(fk ManyToOne), price, quantity, stock_date
const StockSchema = new Schema({
    _id: Number,
    product: { type: Number, ref: "product" },
    price: Number,
    quantity: Number,
    stock_date: Date
})
const StockModel = model("stock", StockSchema)
// cart:- _id#, user(fk ManyToOne), stock(fk ManyToOne), quantity
const CartSchema = new Schema({
    _id: Number,
    user: { type: Number, ref: "user" },
    stock: { type: Number, ref: "stock" },
    quantity: Number
})
const CartModel = model("cart", CartSchema)

// Auto Number/Auto Sequence
const CounterSchema = new Schema({
    _id: String,
    sequence: Number
})

const CounterModel = model("counter", CounterSchema)

const nextId = async (sequenceName) => {
    let cnt = await CounterModel.findByIdAndUpdate(sequenceName, {
        $inc: { sequence: 1 }
    }, { new: true })
    if (cnt === null) {
        cnt = await CounterModel.create({ _id: sequenceName, sequence: 1 })
    }
    return cnt.sequence
}

module.exports = {
    UserType: UserTypeModel,
    User: UserModel,
    Category: CategoryModel,
    Product: ProductModel,
    Stock: StockModel,
    Cart: CartModel,
    nextId
}